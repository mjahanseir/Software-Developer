# 01 Defining Functions


def greet():
    print("Hi there")
    print("Welcome aboard")


greet()
