# 02 Arguments


def greet(first_name, last_name):
    print(f"Hi there {first_name} {last_name}")
    print("Welcome aboard")


greet("Miguel", "Pimenta")
greet("Mosh", "Hamedani")
