def shopping():
    print("Happy shopping")