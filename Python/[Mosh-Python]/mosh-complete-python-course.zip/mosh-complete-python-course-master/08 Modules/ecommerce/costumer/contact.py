def contact_costumer():
    print("Costumer contacted")