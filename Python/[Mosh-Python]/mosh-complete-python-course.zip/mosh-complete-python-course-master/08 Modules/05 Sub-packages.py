# 05 Sub-packages

# As our application grows even bigger, we might want to create sub-folders for better organization.
# We do the same process as in the last lesson.


from ecommerce.shopping.eshopping import shopping

shopping()