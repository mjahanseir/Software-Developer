def calc_tax():
    print("Tax")


def calc_shipping():
    print("Shipping")
