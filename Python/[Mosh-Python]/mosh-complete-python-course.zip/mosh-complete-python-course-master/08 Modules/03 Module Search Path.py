import sales
import sys

# Here we are importing the sales modules. When Pyton sees this it will look for a file names sales.py in the current folder.
# If it is not found it will look in other predetermined folders that come with Python instalation.

print(sys.path) # Here we can return the list of directories where Pyton will look for a module.