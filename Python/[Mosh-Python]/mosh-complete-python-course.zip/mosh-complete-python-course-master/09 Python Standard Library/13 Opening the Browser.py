# 13 Opening the Browser

import webbrowser

# This is about how to open a web browser.
# Import the "webbrowser" module

# For example let's we are building a script to depoloy a website.
# We build the website on our local machine the deploy it to a webserver and at the end we want to open the browser in the website page.

url = "http://docs.python.org/library/webbrowser.html"
webbrowser.open(url)
