# 01 Variables / 2 - Variable Names / 3 - Strings
import math
students_count = 1000
rating = 4.99
is_published = False
course_name = "Python Programming"
print(students_count)
print(rating)
print(course_name)
print(len(course_name))
print(course_name[0])
print(course_name[-2])
print(course_name[0:5])
