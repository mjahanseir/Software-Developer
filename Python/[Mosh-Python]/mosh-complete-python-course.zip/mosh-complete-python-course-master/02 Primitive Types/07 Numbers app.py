# 07 Numbers
# Type of numbers in Python
x = 3  # Integer number
y = 3.1  # Float number
z = 3 + 2j  # Complex number a + bi

print(10 + 3)  # Addition
print(10 - 3)  # Subtration
print(10 * 3)  # Multiplication
print(10 / 3)  # Division
print(10 // 3)  # Division but returns an interger
print(10 % 3)  # Remander of division
print(10 ** 3)  # Exponent

x = x + 3
print(x)
y += 3
print(y)
