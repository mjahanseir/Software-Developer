# 10 Quiz

# What are the primitive type in python?
# Strings
# Interger number
# Float numbers
# Booleans - True and False

# What will we see in the terminal
fruit = "Apple"
print(fruit[1])
# p

# What will we see in the terminal?
fruit = "Apple"
# when slicing a string the last caracter called is not inclued
print(fruit[1:-1])
# ppl

# Waht is the result?
print(10 % 3)
# 1

# Whats the result?
print(bool("False"))
# True
