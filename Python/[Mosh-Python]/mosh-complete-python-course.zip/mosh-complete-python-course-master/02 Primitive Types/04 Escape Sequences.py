# 04 Escape Sequences
# \" for double quotes
course_full_name = "Python Programing with \"Mosh\""
print(course_full_name)
# \' for single quotes
course_full_name = "Python Programing with \'Mosh\'"
print(course_full_name)
# \\ for adding backslash
course_full_name = "Python Programing with \\Mosh\\"
print(course_full_name)
# \n fro new line
course_full_name = "Python Programing with \nMosh"
print(course_full_name)
