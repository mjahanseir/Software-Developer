# 10 Nested Loops
# Loops inside other loops

for x in range(5):
    for y in range(3):
        print(f"({x},{y})")
