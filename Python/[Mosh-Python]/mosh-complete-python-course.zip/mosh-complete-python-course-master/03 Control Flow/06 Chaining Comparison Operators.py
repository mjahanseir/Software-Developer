# 06 Chaining Comparison Operators

# age should be between 18 and 65

age = 22

if age >= 18 and age < 65:
    print("Eligible")

if 18 <= age < 65:
    print("Eligible")

# Line 7 and line 10 are the exact same code
