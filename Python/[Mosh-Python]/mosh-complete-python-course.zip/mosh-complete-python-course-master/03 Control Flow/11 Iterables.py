# 11 Iterables

for x in "Python":
    print(x)

for x in [1, 2, 3, 4]:
    print(x)
