print("Hello World!")
print("*" * 10)
print("Hello World")
x = 1
y = 2
unit_price = 3
