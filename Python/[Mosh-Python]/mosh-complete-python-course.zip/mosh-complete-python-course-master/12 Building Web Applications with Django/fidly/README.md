# fidly
A tutorial project, from Code with Mosh, built with Django.
